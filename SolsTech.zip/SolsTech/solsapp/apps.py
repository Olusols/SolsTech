from django.apps import AppConfig


class SolsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'solsapp'
